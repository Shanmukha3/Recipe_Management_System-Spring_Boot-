package com.example.Spring_recipe;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface RecipeRepository extends JpaRepository<Recipe, Integer>{
	
	 @Query(value = "SELECT * FROM recipe WHERE recipe_name = :recipeName", nativeQuery = true)
	 List<Recipe> getRecipeByName(@Param("recipeName") String recipeName);

}
